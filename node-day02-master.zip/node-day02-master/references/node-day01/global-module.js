var logger = require("./logger");

module.exports.logger = logger;